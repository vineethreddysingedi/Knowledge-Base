export KRB5_CONFIG=/etc/krb5.conf
export KRB5CCNAME=/tmp/krb5cc_14341

java -cp ./*:/opt/cloudera/parcels/CDH/jars/*:/opt/cloudera/parcels/CDH/lib/hive/lib/*:/etc/hive/conf/hive-site.xml -Djava.security.krb5.conf=/etc/krb5.conf -Djava.security.auth.useSubjectCredsOnly=false com.axa.bigdata.ImpalaStatsFromFile "jdbc:hive2://l51hdpp11.na.bigdata.intraxa:21050/;principal=impala/_HOST@NA.BIGDATA.INTRAXA;" $1 $2 $3

inpath='/home/vreddy/impala_stats/work_daas'



while read line
do
	DB=`echo $line | awk -F "~" '{print $1}'`
	TBL=`echo $line | awk -F "~" '{print $3}'`
	CHCK=`echo $line | awk -F "~" '{print $4}'`
	
	if [ "$CHCK" == 'true' ] ; then 
	
		echo $DB.$TBL
		impala-shell -i l51hdpp09 -q "compute stats $DB.$TBL";
	fi
	
done<$inpath/stats_check.log

impala-shell -i l51hdpp15 -q "compute stats  us_aml.loc_grp_addr_accounts";
impala-shell -i l51hdpp15 -q "compute stats  us_aml.loc_grp_addr";
impala-shell -i l51hdpp15 -q "compute stats  us_aml.cust_add_per_org";
impala-shell -i l51hdpp15 -q "compute stats  us_aml.cust_per_org_cont";
impala-shell -i l51hdpp15 -q "compute stats  us_aml.mdm_stage";

rm $inpath/stats_check.log
rm $inpath/stats_check_errors.log

