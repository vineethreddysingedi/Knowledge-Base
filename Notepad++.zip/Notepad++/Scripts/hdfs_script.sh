#!/bin/sh

kinit -kt /home/vreddy/hdfs.keytab hdfs

hdfs dfsadmin -fetchImage /home/vreddy/

output=`ls | grep fsimage_`


current_date=`date +"%Y%m%d"`

#move the fs image from your home folder file to #/home/vreddy/hdfs_reports/hdfs_report/fsimages folder
#run the below command with the latest fs image file to readable csv format

hdfs oiv -i $output -o /home/vreddy/hdfs_reports/hdfs_report/fsimages/fs_image_${current_date}.csv -p Delimited


#run the script form the dir /home/vreddy/hdfs_reports/hdfs_report

sh /home/vreddy/hdfs_reports/hdfs_report/hdfs_report_run.sh /home/vreddy/hdfs_reports/hdfs_report/fsimages/fs_image_${current_date} /home/vreddy/hdfs_reports/hdfs_report/work_daas_${current_date}/

while read cont
do

grep "/river/axa_us/"${cont} /home/vreddy/hdfs_reports/hdfs_report/work_daas_${current_date}/container_missing_acl.csv | cut -d';' -f 1 > ./file_${current_date}.txt

for i in `cat ./file_${current_date}.txt`; do echo -n "$i --> "; hdfs dfs -setfacl -m user::rwx,user:axa_us-sluice:rwx,user:axa_us_${cont}-sluice:rwx,user:hive:rwx,user:impala:rwx,group::rwx,group:axa_us_${cont}:rwx,group:axa_us_${cont}_ro:r-x,mask::rwx,other::--- $i; done

done<./cont_name.txt

rm /home/vreddy/fsimage_*
