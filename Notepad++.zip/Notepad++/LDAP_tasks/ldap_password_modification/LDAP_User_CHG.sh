#!/bin/bash


while read report_CHG
do

	MAIL=`echo $report_CHG | awk -F ":" '{print $1}'` 

	if  [ "$MAIL" != "mail" ]; then 
	
		if  [ "$MAIL" == "dn" ]; then 
			report_CHG_OLD=`echo $report_CHG`
			
		fi
	
	fi  
	
		
	if  [ "$MAIL" == "mail" ]; then 
	
		EMAIL=`echo $report_CHG | awk -F " " '{print $2}'` 
		
		if  [ "$EMAIL" != "no" ]; then 
		
			
			
			while read pp_email
			do	
				EMAIL2=`echo $pp_email | awk -F "~" '{print $1}'`
				CID=`echo $pp_email | awk -F "~" '{print $2}'`
				
				if  [ "$EMAIL" == "$EMAIL2" ]; then 
				
					echo $report_CHG_OLD >>final.txt
					echo 'changetype: modify' >>final.txt
					echo 'replace: userPassword' >>final.txt
					echo 'userPassword: {SASL}'$CID >>final.txt
					echo -en "\n" >>final.txt
					
				fi
			
			done </home/syalamanchili/scripts/pp.txt
		fi 
	
	fi  


done </home/syalamanchili/scripts/report.out
