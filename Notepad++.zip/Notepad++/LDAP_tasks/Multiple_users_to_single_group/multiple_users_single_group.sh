 ##!/bin/bash

while read user;
do
echo DN: cn=axa_us_testing,ou=Containers,dc=bigplay,dc=na,dc=bigdata,dc=intraxa >>users.ldif
echo 'changetype: modify' >>users.ldif
echo 'add: member' >>users.ldif
echo member: uid=$user,ou=Users,dc=bigplay,dc=na,dc=bigdata,dc=intraxa >>users.ldif
echo -en "\n" >>users.ldif

done <./uid.txt