
##!/bin/bash

while read cont;
do
echo DN: cn=$cont,ou=Containers,dc=bigplay,dc=na,dc=bigdata,dc=intraxa >>cont_tent.ldif
echo 'changetype: modify' >>cont_tent.ldif
echo 'add: member' >>cont_tent.ldif
echo member: uid=vreddy,ou=Users,dc=bigplay,dc=na,dc=bigdata,dc=intraxa >>cont_tent.ldif
echo -en "\n" >>cont_tent.ldif

done <./cont.txt

while read tent;
do
echo DN: cn=$tent,ou=Tenants,dc=bigplay,dc=na,dc=bigdata,dc=intraxa >>cont_tent.ldif
echo 'changetype: modify' >>cont_tent.ldif
echo 'add: member' >>cont_tent.ldif
echo member: uid=vreddy,ou=Users,dc=bigplay,dc=na,dc=bigdata,dc=intraxa >>cont_tent.ldif
echo -en "\n" >>cont_tent.ldif

done <./tenant.txt
