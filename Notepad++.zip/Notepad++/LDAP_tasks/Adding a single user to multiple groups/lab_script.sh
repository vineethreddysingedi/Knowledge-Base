#!/bin/bash

while read cont;
do
echo DN: cn=$cont,ou=Containers,dc=lab,dc=lab-na,dc=bigdata,dc=intraxa >>final.txt
echo 'changetype: modify' >>final.txt
echo 'add: member' >>final.txt
echo member: uid=vreddy,ou=Users,dc=lab,dc=lab-na,dc=bigdata,dc=intraxa >>final.txt
echo -en "\n" >>final.txt

done </home/vreddy/cont.txt

		